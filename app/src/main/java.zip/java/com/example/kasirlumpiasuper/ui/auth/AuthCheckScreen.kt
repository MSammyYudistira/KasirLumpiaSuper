package com.example.kasirlumpiasuper.ui.auth

import android.util.Log
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.kasirlumpiasuper.ui.navigation.NavRoutes
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

@Composable
fun AuthCheckScreen(navController: NavHostController) {
    val currentUser = FirebaseAuth.getInstance().currentUser
    val firestore = FirebaseFirestore.getInstance()
    var isChecking by remember { mutableStateOf(true) }

    LaunchedEffect(currentUser) {
        if (currentUser == null) {
            navController.navigate(NavRoutes.Login.route) {
                popUpTo(NavRoutes.AuthCheck.route) { inclusive = true }
            }
            return@LaunchedEffect
        }

        try {
            val snapshot = firestore.collection("users")
                .document(currentUser.uid)
                .get()
                .await()

            if (!snapshot.exists()) {
                FirebaseAuth.getInstance().signOut()
                navController.navigate(NavRoutes.Login.route) {
                    popUpTo(NavRoutes.AuthCheck.route) { inclusive = true }
                }
                return@LaunchedEffect
            }

            val role = snapshot.getString("role") ?: "kasir"
            Log.d("AuthCheckScreen", "User role: $role")

            // ✅ Mark selesai dulu sebelum navigate
            isChecking = false

            // ✅ Lalu navigasi ke Dashboard tunggal
            navController.navigate(NavRoutes.Dashboard.route) {
                popUpTo(NavRoutes.AuthCheck.route) { inclusive = true }
            }

            // ✅ Pastikan efek berhenti agar tidak lanjut setState setelah navigasi
            return@LaunchedEffect

        } catch (e: Exception) {
            Log.e("AuthCheckScreen", "Error fetching user role", e)
            FirebaseAuth.getInstance().signOut()
            navController.navigate(NavRoutes.Login.route) {
                popUpTo(NavRoutes.AuthCheck.route) { inclusive = true }
            }
        } finally {
            isChecking = false
        }
    }

    if (isChecking) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
    }
}

