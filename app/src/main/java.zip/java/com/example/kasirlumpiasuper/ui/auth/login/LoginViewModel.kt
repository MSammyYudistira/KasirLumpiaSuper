package com.example.kasirlumpiasuper.ui.auth.login

import android.util.Log
import android.util.Patterns
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class LoginViewModel : ViewModel() {
    private val firestore = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    var isLoading by mutableStateOf(false)
        private set

    var errorMessage by mutableStateOf<String?>(null)
        private set

    private val _loginState = MutableStateFlow<Result<Boolean>?>(null)
    val loginState: StateFlow<Result<Boolean>?> = _loginState.asStateFlow()

    fun loginUser(
        email: String,
        password: String,
        onResult: (success: Boolean, role: String?, username: String?) -> Unit
    ) {

        // 1️⃣ Validasi dasar
        if (email.isBlank() || password.isBlank()) {
            errorMessage = "Email dan password tidak boleh kosong"
            return
        }

        // 2️⃣ Validasi format email
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            errorMessage = "Format email tidak valid"
            return
        }

        // 3️⃣ Validasi panjang password
        if (password.length < 6) {
            errorMessage = "Password minimal 6 karakter"
            return
        }

        isLoading = true
        errorMessage = null

        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val uid = auth.currentUser?.uid
                    Log.d("LoginViewModel", "Login success, currentUser = $uid")
                    if (uid != null) {
                        firestore.collection("users")
                            .document(uid)
                            .get()
                            .addOnSuccessListener { document ->
                                if (!document.exists()) {
                                    // 🚫 Jika dokumen user tidak ada di Firestore
                                    errorMessage = "Akun belum terdaftar di database"
                                    FirebaseAuth.getInstance().signOut()
                                    isLoading = false
                                    onResult(false, null, null)
                                    return@addOnSuccessListener
                                }

                                val role = document.getString("role") ?: "kasir"
                                val username = document.getString("name") ?: ""
                                onResult(true, role, username)
                                isLoading = false
                            }
                            .addOnFailureListener { e ->
                                errorMessage = "Gagal mengambil data user: ${e.message}"
                                isLoading = false
                                onResult(false, null, null)
                            }
                    } else {
                        isLoading = false
                        errorMessage = "User ID tidak ditemukan."
                        onResult(false, null, null)
                    }
                } else {
                    isLoading = false
                    errorMessage = "Login gagal. Email atau password salah."
                    onResult(false, null, null)
                }
            }
    }

    fun resetPassword(
        email: String,
        onResult: (Boolean) -> Unit
    ) {
        if (email.isBlank()) {
            errorMessage = "Mohon isi email terlebih dahulu."
            onResult(false)
            return
        }
        isLoading = true
        errorMessage = null

        auth.sendPasswordResetEmail(email)
            .addOnCompleteListener { task ->
                isLoading = false
                if (task.isSuccessful) {
                    onResult(true)
                } else {
                    errorMessage = task.exception?.message ?: "Gagal mengirim email reset password."
                    onResult(false)
                }
            }
    }
}