package com.example.kasirlumpiasuper.ui.stock

import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.kasirlumpiasuper.data.model.StockInputItem
import com.example.kasirlumpiasuper.data.model.StockMeta
import com.example.kasirlumpiasuper.ui.components.CustomActionButton
import com.example.kasirlumpiasuper.ui.components.CustomTopBarWithBackAction
import com.example.kasirlumpiasuper.ui.dashboard.DashboardViewModel
import com.example.kasirlumpiasuper.ui.navigation.NavRoutes
import com.example.kasirlumpiasuper.ui.recap.RecapViewModel
import com.example.kasirlumpiasuper.ui.theme.Surface

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StockScreen(
    navController: NavHostController,
    recapViewModel: RecapViewModel
) {
    val kasirViewModel: DashboardViewModel = viewModel()
    val context = LocalContext.current
    val stok = listOf("Lumpia", "Tahu Lumpia", "Siomay", "Siomay Basah", "Mihun", "Singkong Goreng", "Kacang Merah", "Aqua")

    val initialStocks = remember { mutableStateMapOf<String, Int>() }
    val damagedStocks = remember { mutableStateMapOf<String, Int>() }
    var uangKas by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            CustomTopBarWithBackAction(
                onBackClick = {
                    val popped = navController.popBackStack()
                    Log.d(
                        "Stock Screen",
                        "Back Pressed, Result: $popped, current route: ${NavRoutes.Stock.route}"
                    )
                },
                title = "Atur Stok"
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding)
                .padding(horizontal = 72.dp),
        ) {
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    shape = RoundedCornerShape(8.dp),
                    shadowElevation = 4.dp
                ) {
                    Column {
                        Text(
                            "Stok Awal",
                            style = MaterialTheme.typography.displaySmall,
                            modifier = Modifier
                                .padding(start = 24.dp, top = 24.dp, bottom = 16.dp)
                        )
                        stok.forEach { product ->
                            var value by remember { mutableStateOf("")}
                            OutlinedTextField(
                                value = value,
                                onValueChange = {
                                    value = it.filter ( Char::isDigit )
                                    initialStocks[product] = value.toIntOrNull() ?: 0
                                },
                                label = { Text(product) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 24.dp, vertical = 8.dp)
                            )
                        }
                    }
                }
            }

            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 24.dp),
                    shape = RoundedCornerShape(8.dp),
                    shadowElevation = 4.dp
                ) {
                    Column {
                        Text(
                            "Stok Rusak / Retur",
                            style = MaterialTheme.typography.displaySmall,
                            modifier = Modifier
                                .padding(start = 24.dp, top = 24.dp, bottom = 16.dp)
                        )
                        stok.forEach { product ->
                            var value by remember { mutableStateOf("") }
                            OutlinedTextField(
                                value = value,
                                onValueChange = {
                                    value = it.filter(Char::isDigit)
                                    damagedStocks[product] = value.toIntOrNull() ?: 0
                                },
                                label = { Text(product) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 24.dp, vertical = 8.dp)
                            )
                        }
                    }
                }
            }

            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 24.dp),
                    shape = RoundedCornerShape(8.dp),
                    shadowElevation = 4.dp
                ) {
                    Column{
                        Text(
                            "Uang Yang Dibawa",
                            style = MaterialTheme.typography.displaySmall,
                            modifier = Modifier
                                .padding(start = 24.dp, top = 24.dp, bottom = 16.dp)
                        )

                        OutlinedTextField(
                            modifier = Modifier.fillMaxWidth().padding(24.dp),
                            value = uangKas,
                            onValueChange = { uangKas = it.filter(Char::isDigit) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            textStyle = MaterialTheme.typography.displaySmall.copy(textAlign = TextAlign.Center),
                            colors = TextFieldDefaults.colors(unfocusedContainerColor = Surface),
                        )
                    }
                }
            }

            item {
                CustomActionButton(
                    onClicked = {
                        val items = stok.map {
                            StockInputItem(
                                productId = it,
                                name = it,
                                initialStock = initialStocks[it] ?: 0,
                                damagedStock = damagedStocks[it] ?: 0
                            )
                        }
                        val meta = StockMeta(cashOpening = uangKas.toIntOrNull() ?: 0)
                        recapViewModel.saveStockInput(
                            items = items,
                            meta = meta,
                            onSuccess = {
                                Toast.makeText(context, "Stok berhasil disimpan!", Toast.LENGTH_SHORT).show()
                                kasirViewModel.isStockFilledToday(isStockFilled = true)
                                navController.popBackStack()
                            },
                            onError = { err ->
                                Toast.makeText(context, err, Toast.LENGTH_SHORT).show()
                            }
                        )
                    },
                    text = "Simpan Perubahan"
                )
            }
        }
    }
}