package com.example.kasirlumpiasuper.ui.navigation

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navigation
import com.example.kasirlumpiasuper.data.repository.FirestoreViewModel
import com.example.kasirlumpiasuper.ui.auth.AuthCheckScreen
import com.example.kasirlumpiasuper.ui.auth.login.LoginScreen
import com.example.kasirlumpiasuper.ui.auth.signup.SignupScreen
import com.example.kasirlumpiasuper.ui.components.CustomTopBar
import com.example.kasirlumpiasuper.ui.components.TopBarMenu
import com.example.kasirlumpiasuper.ui.dashboard.DashboardScreen
import com.example.kasirlumpiasuper.ui.history.HistoryScreen
import com.example.kasirlumpiasuper.ui.history.HistoryViewModel
import com.example.kasirlumpiasuper.ui.history.OrderDetailScreen
import com.example.kasirlumpiasuper.ui.payment.PaymentScreen
import com.example.kasirlumpiasuper.ui.payment.PaymentViewModel
import com.example.kasirlumpiasuper.ui.profile.ProfileScreen
import com.example.kasirlumpiasuper.ui.recap.DetailRecapScreen
import com.example.kasirlumpiasuper.ui.recap.InputRecapScreen
import com.example.kasirlumpiasuper.ui.recap.RecapViewModel
import com.example.kasirlumpiasuper.ui.splash.SplashScreen
import com.example.kasirlumpiasuper.ui.stats.StatisticScreen
import com.example.kasirlumpiasuper.ui.stock.StockScreen
import com.example.kasirlumpiasuper.ui.transaction.TransactionScreen
import com.example.kasirlumpiasuper.ui.transaction.TransactionViewModel

@SuppressLint("UnrememberedGetBackStackEntry", "StateFlowValueCalledInComposition")
@Composable
fun KasirNavHost() {
    val navController = rememberNavController()
    val firestoreViewModel: FirestoreViewModel = viewModel()

    NavHost(
        navController = navController,
        startDestination = NavRoutes.Splash.route,
    ) {
        composable(NavRoutes.Splash.route) {
            SplashScreen {
                navController.navigate(NavRoutes.AuthCheck.route) {
                    popUpTo(NavRoutes.Splash.route) { inclusive = true }
                }
            }
        }

        composable(NavRoutes.AuthCheck.route) { AuthCheckScreen(navController) }
        composable(NavRoutes.Login.route) { LoginScreen(navController) }
        composable(NavRoutes.Signup.route) { SignupScreen(navController) }

        navigation(
            startDestination = NavRoutes.Dashboard.route,
            route = "main"
        ) {

            composable(NavRoutes.Dashboard.route) {
                MainScaffold(
                    navController = navController,
                    viewModel = firestoreViewModel
                ) { innerPadding ->
                    Box(Modifier.padding(innerPadding)) {
                        DashboardScreen(
                            navController
                        )
                    }
                }
            }

//            composable(NavRoutes.DashboardKasir.route) {
//                MainScaffold(
//                    navController = navController,
//                    viewModel = firestoreViewModel
//                ) { innerPadding ->
//                    Box(Modifier.padding(innerPadding)) {
//                        KasirDashboard(navController)
//                    }
//                }
//            }
//            composable(NavRoutes.DashboardAdmin.route) {
//                MainScaffold(
//                    navController = navController,
//                    viewModel = firestoreViewModel
//                ) { innerPadding ->
//                    Box(Modifier.padding(innerPadding)) {
//                        AdminDashboard(navController = navController)
//                    }
//                }
//            }
            composable(NavRoutes.Profile.route) {
                MainScaffold(
                    navController = navController,
                    viewModel = firestoreViewModel
                ) { innerPadding ->
                    Box(Modifier.padding(innerPadding)) {
                        ProfileScreen(navController)
                    }
                }
            }
            composable(NavRoutes.History.route) {
                MainScaffold(
                    navController = navController,
                    viewModel = firestoreViewModel
                ) { innerPadding ->
                    Box(Modifier.padding(innerPadding)) {
                        HistoryScreen(navController)
                    }
                }
            }
            composable(NavRoutes.Statistic.route) {
                MainScaffold(
                    navController = navController,
                    viewModel = firestoreViewModel
                ) { innerPadding ->
                    Box(Modifier.padding(innerPadding)) {
                        StatisticScreen(navController)
                    }
                }
            }

            composable(NavRoutes.Stock.route) { backStackEntry ->
                val recapViewModel: RecapViewModel = viewModel(backStackEntry)
                StockScreen(
                    navController,
                    recapViewModel = recapViewModel
                )
            }

            composable(
                route = "${NavRoutes.InputRecap.route}/{dateLabel}"
            ) { backStackEntry ->
                val recapViewModel: RecapViewModel = viewModel()
                val dateLabel = backStackEntry.arguments?.getString("dateLabel") ?: ""

                InputRecapScreen(
                    navController = navController,
                    recapViewModel = recapViewModel,
                    dateLabel = dateLabel
                )
            }

            composable(
                route = "${NavRoutes.DetailRecap.route}/{dateLabel}"
            ) { backStackEntry ->
                val recapViewModel: RecapViewModel = viewModel()
                val dateLabel = backStackEntry.arguments?.getString("dateLabel") ?: ""

                DetailRecapScreen(
                    navController = navController,
                    recapViewModel = recapViewModel,
                    dateLabel = dateLabel
                )
            }

            composable(
                route = "${NavRoutes.OrderDetail.route}/{dateKey}/{queueNumber}"
            ) { backStackEntry ->
                val dateKey = backStackEntry.arguments?.getString("dateKey") ?: return@composable
                val queueNumber = backStackEntry.arguments?.getString("queueNumber")?.toIntOrNull()
                    ?: return@composable

                // 🔹 Ambil HistoryViewModel dari parentEntry "main"
                val parentEntry = remember(navController) {
                    navController.getBackStackEntry("main")
                }
                val historyViewModel: HistoryViewModel = viewModel(parentEntry)

                OrderDetailScreen(
                    navController = navController,
                    dateKey = dateKey,
                    queueNumber = queueNumber,
                    viewModel = historyViewModel
                )
            }

            composable(NavRoutes.Transaction.route) { backStackEntry ->
                val transactionViewModel: TransactionViewModel = viewModel(backStackEntry)
                TransactionScreen(
                    navController = navController,
                    transactionViewModel = transactionViewModel
                )
            }

            composable(NavRoutes.Payment.route) { backStackEntry ->
                val transactionViewModel: TransactionViewModel =
                    viewModel(navController.getBackStackEntry(NavRoutes.Transaction.route))
                val paymentViewModel: PaymentViewModel = viewModel(backStackEntry)
                PaymentScreen(
                    navController = navController,
                    paymentViewModel = paymentViewModel,
                    transactionViewModel = transactionViewModel
                )
            }
        }
    }
}

@Composable
fun MainScaffold(
    navController: NavHostController,
    viewModel: FirestoreViewModel,
    content: @Composable (PaddingValues) -> Unit,
) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val selectedMenu = when (currentRoute) {
        NavRoutes.Dashboard.route -> TopBarMenu.DASHBOARD
        NavRoutes.History.route -> TopBarMenu.HISTORY
        NavRoutes.Statistic.route -> TopBarMenu.STATS
        NavRoutes.Profile.route -> TopBarMenu.PROFILE
        else -> TopBarMenu.DASHBOARD
    }

    val user by viewModel.user.collectAsState()
    val showStats = user?.role == "admin"

//    val dashboardRoute = if (user?.role == "admin") {
//        NavRoutes.DashboardAdmin.route
//    } else {
//        NavRoutes.DashboardKasir.route
//    }

    Scaffold(
        topBar = {
            CustomTopBar(
                onHomeClick = { navController.navigateSingleTopTo(NavRoutes.Dashboard.route) },
                onHistoryClick = { navController.navigateSingleTopTo(NavRoutes.History.route) },
                onProfileClick = { navController.navigateSingleTopTo(NavRoutes.Profile.route) },
                onStatsClick = if (showStats) {
                    { navController.navigateSingleTopTo(NavRoutes.Statistic.route) }
                } else null,
                onSelectedMenu = selectedMenu,
                viewModel = viewModel
            )
        }
    ) { innerPadding ->
        content(innerPadding)
    }
}
